/*
 * Init Lab - libq4.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _LIBQ4_H
#define _LIBQ4_H

#include <stdint.h>

void evaluateQuestion4();
void _question4B(uint64_t x, uint64_t *result);

#endif