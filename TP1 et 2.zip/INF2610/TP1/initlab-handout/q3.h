/*
 * Init Lab - q3.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _Q3_H
#define _Q3_H

void question3();

#endif