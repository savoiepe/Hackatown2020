#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <fcntl.h>

/*
 * Init Lab - q3.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------

// -------------------------------------------------

/*
 * Vous devez imprimer dans le fichier indiqué dans l'énoncé le message suivant:
 *  
 * This file has been opened by process ID CURRENT_PID.
 * 
 * - En terminant le message par le caractère '\n' de fin de ligne
 * - En remplaçant CURRENT_PID par le PID du processus qui exécutera votre solution
 */
void question3() {
    // TODO
    // FILE * fp;
    // fp = fopen("q3Output-285c034a7706.txt", "w");
    // fprintf(fp,"This file has been opened by process ID %d.\n",getpid());
    // fclose(fp);
    
    int fp = open("q3Output-285c034a7706.txt", O_WRONLY | O_TRUNC);
    char buffer[50];
    sprintf(buffer, "This file has been opened by process ID %d.\n",getpid());
    write(fp, buffer, sizeof(buffer));
    close(fp);
}