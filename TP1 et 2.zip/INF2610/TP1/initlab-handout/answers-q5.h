/*
 * Init Lab - answers-q5.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _ANSWERS_Q5_H
#define _ANSWERS_Q5_H

// -----------------------------------------------------------------
// Reportez ici les réponses que vous avez trouvées à la question 5.
// -----------------------------------------------------------------

// Report here the answer for question 5. a)
char Q5_ANS_A[] = "/tmp/filewriter_secret_60d8fdc8ce99fe58"; //TODO

// Report here the answer for question 5. b)
char Q5_ANS_B[] = "/tmp/filewriter_secret_child_3f7db593c78ead91"; //TODO

// Report here the answer for question 5. c)
char Q5_ANS_C[] = "41215ca01c5c5c756a96c764fa174601951bb0aeb9d0e2043d9e869e6b885509"; //TODO

// Report here the answer for question 5. d)
char Q5_ANS_D[] = "fputs"; //TODO

// Report here the answer for question 5. e)
char Q5_ANS_E[] = "WAIT_TIME"; //TODO

#endif