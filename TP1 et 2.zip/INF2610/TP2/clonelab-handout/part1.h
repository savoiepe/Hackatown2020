/*
 * Clone Lab - part1.h
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#ifndef _PART1_H
#define _PART1_H

void part1();

#endif