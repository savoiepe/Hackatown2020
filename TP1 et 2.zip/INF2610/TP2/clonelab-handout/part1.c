/*
 * Clone Lab - part1.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

// -------------------------------------------------

void part1() {
    // TODO
    pid_t pidDuFils = fork();  
    if(pidDuFils ==0){
        pid_t pidDuPere = getppid();

        char buffer[50];
        sprintf(buffer, "%d", pidDuPere);
        execl("./part1/earle","earle", "--P",buffer, NULL);
    }
    char buffer[50];
    sprintf(buffer, "%d", pidDuFils); 
    execl("./part1/rickie","rickie", "--P",buffer, NULL);

}