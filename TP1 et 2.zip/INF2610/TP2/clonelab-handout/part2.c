/*
 * Clone Lab - part2.c
 * 
 * Ecole polytechnique de Montreal, 2018
 */

#include "libclonelab.h"
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>       
#include <sys/wait.h>


// TODO
// Si besoin, ajouter ici les directives d'inclusion
// -------------------------------------------------

// -------------------------------------------------

#define PART2_OUTPUT_FILE_PATH "part2Output.txt"

void part2() {
    // Ouverture du fichier de sortie pour la question 2.3
    FILE* part2OutputFile = fopen(PART2_OUTPUT_FILE_PATH, "a");

    pid_t pidMasterPapa = getpid();
    char buffer[50];
    sprintf(buffer, "%d", pidMasterPapa);

    // TODO
    fprintf(part2OutputFile,"Root process has pid %d (message from process",pidMasterPapa);
    if(fork() == 0){
        if(fork() == 0){
            registerProc(2, 1, getpid(), getppid());
            fprintf(part2OutputFile," level2.1)\n");
            fclose(part2OutputFile);
            execl("./part2/level2.1","level2.1", buffer,NULL);
            exit(0);
        }

        if(fork() == 0){
            registerProc(2, 2, getpid(), getppid());
            char* env[] =  {"NOREPORT=3cef6270f36c0c65d294a21f",NULL};

            execle("./part2/level2.2","level2.2", buffer, NULL, env);
            exit(0);
        }
        wait(NULL);
        wait(NULL);
        registerProc(1, 1, getpid(), getppid());
        execl("./part2/level1.1","level1.1", buffer, NULL);
        exit(0);
    }

    if(fork() == 0){
        if(fork() == 0){
            registerProc(2, 3, getpid(), getppid());
            fprintf(part2OutputFile," level2.3)\n");
            fclose(part2OutputFile);
            execl("./part2/level2.3","level2.3", buffer, NULL);

            exit(0);
        }
        wait(NULL);
        registerProc(1, 2, getpid(), getppid());
        execl("./part2/level1.2","level1.2", buffer, NULL);
        exit(0);
    }

    if(fork() == 0){
        if(fork() == 0){
            registerProc(2, 4, getpid(), getppid());
            execl("./part2/level2.4","level2.4", buffer, NULL);

            exit(0);
        }
        wait(NULL);
        registerProc(1, 3, getpid(), getppid());
        fprintf(part2OutputFile," level1.3)\n");
        fclose(part2OutputFile);
        execl("./part2/level1.3","level1.3", buffer, NULL);
        exit(0);
    }

    if(fork() == 0){
        if(fork() == 0){
            registerProc(2, 5, getpid(), getppid());
            fprintf(part2OutputFile," level2.5)\n");     
            fclose(part2OutputFile);       
            execl("./part2/level2.5","level2.5", buffer, NULL);
            exit(0);
        }
        wait(NULL);
        registerProc(1, 4, getpid(), getppid());
        fprintf(part2OutputFile," level1.4)\n");
        fclose(part2OutputFile);
        execl("./part2/level1.4","level1.4", buffer, NULL);
        exit(0);
    }
    wait(NULL);
    wait(NULL);
    wait(NULL);
    wait(NULL);

    fprintf(part2OutputFile," level0)\n");
    fclose(part2OutputFile);

    execl("./part2/level0","level0","11d9a1fa243f5a7d16cab6ee", NULL);


}
